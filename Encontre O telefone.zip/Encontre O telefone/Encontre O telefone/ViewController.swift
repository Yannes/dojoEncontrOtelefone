//
//  ViewController.swift
//  Encontre O telefone
//
//  Created by Yan Meneguelli on 28/01/19.
//  Copyright © 2019 Yan Meneguelli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTelefone: UILabel!
    var array:Array<String> = []
    
    @IBOutlet weak var textFieldCaracteres: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    


    @IBAction func buttonGerarTelefone(_ sender: UIButton) {
        let result = textFieldCaracteres.text!.uppercased().split(separator: "-")
        for teste in result{
            _ = teste.map { (Character) -> Character in
                switch Character{
                case "A","B","C":
                    let teste1 = "2"
                    array.append(teste1)
                    break
                case "D","E","F":
                    let teste1 = "3"
                    array.append(teste1)
                    break
                case "G","H","I":
                    let teste1 = "4"
                    array.append(teste1)
                    break
                case "J","K","L":
                    let teste1 = "5"
                    array.append(teste1)
                    break
                case "M","N","O":
                    let teste1 = "6"
                    array.append(teste1)
                    break
                case "P","Q","R","S":
                    let teste1 = "7"
                    array.append(teste1)
                    break
                case "T","U","V":
                    let teste1 = "8"
                    array.append(teste1)
                    break
                case "W","X","Y","Z":
                    let teste1 = "9"
                    array.append(teste1)
                    break
                case "0":
                    let teste1 = "0"
                    array.append(teste1)
                    break
                case "1":
                    let teste1 = "1"
                    array.append(teste1)
                    break
                default:
                    break
                }
                return Character
            }
        }
        let characterArray = array.flatMap {String($0)}
        let string = String(characterArray)
        lblTelefone.text = string
    }
}

